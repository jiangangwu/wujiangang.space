import tkinter as tk # 是python自带的图形化类，包括窗体、标签、按钮、输入框等都可以定义。
import random        # 随机数生成器
from threading import Lock # 多线程管理
import time # 时间管理的库
import tkinter.messagebox
import os
COLORS = ['black', 'yellow', 'orange', 'blue', 'red', 'magenta', 'green', 'cyan'] # 可以改用不可更改的格式
try:
    file = open(os.getcwd() + '/.score.txt', mode='r', encoding='UTF-8')
    file_content = file.read()
    file.close()
    HIGHEST_SCORE_OF_HISTORY = int(file_content)
except:
    try:
        file = open(os.getcwd() + '/.score.txt', mode='w+', encoding='UTF-8')
        file.write('0')
        file.close()
    except:
        pass
    HIGHEST_SCORE_OF_HISTORY = 0
class Tetris(): # 不用继承，所在类的括号里为空

    FIELD_HEIGHT = 20 # 为小方块，后面应该需要生成
    FIELD_WIDTH = 10
    SCORE_PER_ELIMINATED_LINES = (0, 100, 200, 400, 800)
    TETROMINOS = [ # 四连方是一种多边方（多个相同方格构成的图案），有七种，其中O是旋转对称的，T、I是左右对称的。其中s与z、L与J是镜面不对称的，不能视作同一种
        [(0, 0), (0, 1), (1, 0), (1, 1)], # O  第一个表示行，第二个表示列，由上往下，由左往右编号，其中行都是从0开始
        [(0, 0), (0, 1), (1, 1), (2, 1)], # L
        [(0, 1), (1, 1), (2, 0), (2, 1)], # J  初始位置0行，1列，2行，0列
        [(0, 1), (1, 0), (1, 1), (2, 0)], # Z
        [(0, 1), (1, 0), (1, 1), (2, 1)], # T
        [(0, 0), (1, 0), (1, 1), (2, 1)], # S
        [(0, 1), (1, 1), (2, 1), (3, 1)], # I
        ]
    TYPE = ['O','L','J','Z','T','S','I']
    total = 1
    
    def __init__(self):
        self.field = [[0 for c in range(Tetris.FIELD_WIDTH)] for r in range(Tetris.FIELD_HEIGHT)]  # 表示所有方块的色彩相对位置，初始全部是零，表示该处是否要涂上色彩
        self.score = 0
        self.level = 0
        self.total_lines_eliminated = 0
        self.game_over = False
        self.game_start_again = False
        self.times = 1
        self.move_lock = Lock() # 表示运行当前函数时，进行入分线程，主要是向下移动与旋转相互冲突，要等一个动作完成才进行另一动作
        self.choice_next = random.randint(0, 6)
        self.tetris_type = Tetris.TYPE[self.choice_next]
        self.reset_tetromino()  # 下面的函数
        
    def reset_tetromino(self):
        self.choice = self.choice_next
        self.choice_next = random.randint(0, 6)
        self.tetris_type = Tetris.TYPE[self.choice_next]
        self.tetromino = Tetris.TETROMINOS[self.choice]    # 随机选形态        
        self.tetromino_color = self.choice + 1 # 随机选五种色彩，灰色为底色，不用选
        self.tetromino_offset = [-2, (random.randint(-1, 8) if self.choice == 6 else random.randint(0, 8))]     # 产生4阶方块时的初始坐标，从-2的高度开始
        self.game_over = any(not self.is_cell_free(r, c) for (r, c) in self.get_tetromino_coords()) # 判断是否结束，条件是任意一个为真：检查当前所有方块的坐标，看其是否在正常范围内
        
    
    def get_tetromino_coords(self): # 获取每个方块当前坐标，为四阶方块坐标加上各自相对坐标
        return [(r+self.tetromino_offset[0], c + self.tetromino_offset[1]) for (r, c) in self.tetromino]

    def apply_tetromino(self):  
        for (r, c) in self.get_tetromino_coords(): # 假如当前坐标被四连方占有
            self.field[r][c] = self.tetromino_color # 更新方块的默认色彩为当前四连方色彩

        new_field = [row for row in self.field if any(tile == 0 for tile in row)] # 至少有一个灰方块的行的列表
        lines_eliminated = len(self.field)-len(new_field) # 没有灰方块的长度
        self.total_lines_eliminated += lines_eliminated   # 总的被消除行数，用于统计水平
        self.field = [[0]*Tetris.FIELD_WIDTH for x in range(lines_eliminated)] + new_field  # 把至少有一个灰方块的行下沉，在上面添加灰色行
        self.score += Tetris.SCORE_PER_ELIMINATED_LINES[lines_eliminated] * (self.level + 1)
        if self.level == 0 and self.total_lines_eliminated > 10: 
            self.level = 1
        if self.level == 1 and self.total_lines_eliminated > 30: 
            self.level = 2
        if self.level == 2 and self.total_lines_eliminated > 60: 
            self.level = 3
        if self.level == 3 and self.total_lines_eliminated > 100: 
            self.level = 4
        if self.level == 4 and self.total_lines_eliminated > 150: 
            self.level = 5
        if self.level == 5 and self.total_lines_eliminated > 210: 
            self.level = 6
        if self.level == 6 and self.total_lines_eliminated > 280: 
            self.level = 7
        if self.level == 7 and self.total_lines_eliminated > 360: 
            self.level = 8
        if self.level == 8 and self.total_lines_eliminated > 450: 
            self.level = 9
        self.reset_tetromino()

    def get_color(self, r, c): # 通过行和列，给出色彩，如果方块是当前四连方，就给当前方块的色彩，不然就给整个方块的原来色彩，这个原来色彩也是不断更新的，每次出新块前更新一次
        return self.tetromino_color if (r, c) in self.get_tetromino_coords() else self.field[r][c]
    
    def is_cell_free(self, r, c): # 检查是不是可以自由移动。要求行小于高度，列大于等于0，小于宽度，并且行或者小于0（准备出块区域，不画出来）或者该坐标色彩为灰，即没有被占用。概括来说，要求该小方格在区域内或没被占。是否被占看是否色彩已经不是默认色（灰色）。
        return r < Tetris.FIELD_HEIGHT and 0 <= c < Tetris.FIELD_WIDTH and (r < 0 or self.field[r][c] == 0)
    
    def move(self, dr, dc): # 移动行数dr，和列dc
        with self.move_lock: # 移动时，要求锁定该线程，因为它与旋转冲突，要求完成一者才能做另一者
            if self.game_over:
                return
            else:
                self.game_start_again = False

            if all(self.is_cell_free(r + dr, c + dc) for (r, c) in self.get_tetromino_coords()): # 四连方每个方块都自由的情况下，更新坐标
                self.tetromino_offset = [self.tetromino_offset[0] + dr, self.tetromino_offset[1] + dc] # 四连方坐标更新
            elif dr == 1 and dc == 0: # 如果只是向下移动
                self.game_over = any(r < 0 for (r, c) in self.get_tetromino_coords()) # 检查是否游戏结束
                if not self.game_over:
                    self.apply_tetromino() # 如果没有结束，更新色彩，更新消除

    def rotate(self):
        with self.move_lock: # 旋转时，要求锁定该线程，因为它与移动冲突，要求完成一者才能做另一者
            if self.game_over:
                self.__init__()
                self.game_start_again = True
                self.total += 1
                return

            ys = [r for (r, c) in self.tetromino]  # 所有行坐标构成的列表
            xs = [c for (r, c) in self.tetromino]  # 所有列坐标构成的列表
            size = max(max(ys) - min(ys), max(xs)-min(xs))  # 最大列宽、最大行宽中的最大值
            rotated_tetromino = [(c, size-r) for (r, c) in self.tetromino] # 行列颠倒，沿45度线，旋转90度，进行横竖转换，但形成的方块也变成了原来的镜像，而且原来是沿向右、向下的，变成了向上、向左了，需要让方块向右翻转并平移；对列进行与最大值取差的变换，沿x=size/2这条线向右翻转。这里要注意，坐标是向右、向下为正的。这样翻转不会出左边界，但可能出右边界（当最靠近右边时）。但所有列都减一，也可能出左边界。以下加上绝对坐标后，进行调整。
            wallkick_offset = self.tetromino_offset[:] # 原来绝对坐标，赋给临时变量。这里的绝对坐标是指最左上的那个方格的坐标。
            tetromino_coord = [(r+wallkick_offset[0], c + wallkick_offset[1]) for (r, c) in rotated_tetromino]  # 更新每个方块绝对坐标
            # 如果列靠最右，就没办法变形了，因为可能超出右边框。以下进行调整。
            min_x = min(c for r, c in tetromino_coord) # 列最小的值，为了检测是不是出窗口左侧
            max_x = max(c for r, c in tetromino_coord) # 列最大的值，为了检测是不是出窗口右侧
            max_y = max(r for r, c in tetromino_coord) # 行最大的值，为了检测是不是出窗口右侧
            wallkick_offset[1] -= min(0, min_x)        # 如果出了左边界，将基拉回来。
            wallkick_offset[1] += min(0, Tetris.FIELD_WIDTH - (1 + max_x))  # 如果刚好紧挨着右边界或超出，都将其拉回来，使其刚好离右边界空一个方块，以方便变形后还在界内。
            wallkick_offset[0] += min(0, Tetris.FIELD_HEIGHT - (1 + max_y)) # 如果刚好靠着下边界就让其与下边界空一格。

            tetromino_coord = [(r+wallkick_offset[0], c + wallkick_offset[1]) for (r, c) in rotated_tetromino] # 重新给变换后的四连方赋上坐标值
            if all(self.is_cell_free(r, c) for (r, c) in tetromino_coord):  # 检查方块是否被占。为什么可能被占呢？因为该处可能已经有四连方了，或超过边界了，这样就不允许旋转了。
                self.tetromino, self.tetromino_offset = rotated_tetromino, wallkick_offset # 如果四连方的每个方块都是自由的，将其赋值给对象。

class Application(tk.Frame): # 输入参数为tk的框架，
    count = 1
    running = True
    T1 = time.time()
    T2 = time.time()
    T3 = T2 - T1
    biggest_score = 0
    def __init__(self, master=None): # master指上一级，这里没有上一级，本级是root，接下来是Frame，接下来是Widgets
        super().__init__(master) # 也可以把super()改成"tk.Frame.",表示从原程序直接拷贝相关代码进来。原代码为对主窗口（root）进行初始化。即有标题栏（tk），有最大化、最小化和关闭按钮。
        
        self.tetris = Tetris() # 生成一个类的对象
        self.pack() # 原程序拷贝进来的相关可视化设置放进主窗口
        self.create_widgets() # 自定义函数，生成20行*10列方块，生成类的对象时，直接运行函数
        self.update_clock()   # 自定义函数，不断的递归调用自己使游戏不断进行，生成类时，直接运行        

    def update_clock(self): 
        self.tetris.move(1, 0) # 四连方的坐标向下移动一格
        self.update()          # 对方块进行填色
        if self.running and self.tetris.game_over==False:
            self.T2 = time.time()
        if self.running:
            self.master.after(int(1000*(0.6667**self.tetris.level)), self.update_clock) # 根据级别增加速度。向下移动的速度为1秒乘0.66的级别次方        
            
    def create_widgets(self):  # 画出整个窗口内部的方块，每个方块35px*35px
        PIECE_SIZE = 35   # 表示三十个像素
        self.canvas = tk.Canvas(self, height=PIECE_SIZE*self.tetris.FIELD_HEIGHT,     # 画布大小、背景和边框
                                      width = PIECE_SIZE*self.tetris.FIELD_WIDTH, bd=-1, relief='raised', bg='black') 
        self.rectangles = [     # 画布上给出所以方格
            self.canvas.create_rectangle(c*PIECE_SIZE, r*PIECE_SIZE, (c+1)*PIECE_SIZE, (r+1)*PIECE_SIZE, outline='dimgray')
                for r in range(self.tetris.FIELD_HEIGHT) for c in range(self.tetris.FIELD_WIDTH)
        ]
        
        self.canvas.bind('<Left>', lambda _: (self.tetris.move(0, -1), self.update())) # 画布绑定事件，上下左右键，每次移动或旋转之后，更新方块色彩
        self.canvas.bind('<Right>', lambda _: (self.tetris.move(0, 1), self.update()))
        self.canvas.bind('<Down>', lambda _: (self.tetris.move(1, 0), self.update()))
        self.canvas.bind('<Up>', lambda _: (self.tetris.rotate(), self.update()))
        self.canvas.bind('<space>', lambda _: (self.stop(), self.update())) # 按空格键暂停1小时，再次按将继续
        self.canvas.focus_set() # 接收键盘事件
        self.canvas.pack(side="right") # 画布向左放
        self.canvas2 = tk.Canvas(self, height=int(PIECE_SIZE*4.2),     # 画布大小、背景和边框
                                      width = int(PIECE_SIZE*4.2), bd=-3, relief='sunken', bg='black') 
        self.rectangles2 = [     # 画布上给出所以方格
            self.canvas2.create_rectangle((c+1)*PIECE_SIZE//7*5, (r+1)*PIECE_SIZE//7*5, (c+2)*PIECE_SIZE//7*5, (r+2)*PIECE_SIZE//7*5)
                for r in range(4) for c in range(4)
        ]
        self.canvas2.pack(side="top") # 画布向左放
        self.status_msg = tk.Label(self, anchor='n', bg='black', width=11, font=("Courier", 20), fg='silver') # 标签，消息，上部
        self.status_msg.pack(side="top") # 打包
        self.timer_msg = tk.Label(self, anchor='n', bg='black', width=11, font=("Courier", 20), fg='gray') # 标签，消息，上部
        self.timer_msg.pack(side="top") # 打包
        self.timer_accumulation_msg = tk.Label(self, anchor='n', bg='black', width=18, font=("Courier", 14), fg='gray') # 标签，消息，上部
        self.timer_accumulation_msg.pack(side="top") # 打包
        self.game_over_msg = tk.Label(self, anchor='n', bg='black', width=11, font=("Courier", 20), fg='red') # 标签，消息，上部，前景为红色
        self.game_over_msg.pack(side="top") # 打包
        self. instruction_msg = tk.Label(self, anchor='n', bg='black', width=16, font=("song", 13), fg='gray') # 标签，消息，上部，前景为红色
        self.instruction_msg.pack(side="top") # 打包
    
    def stop(self):
        self.count += 1
        if self.count%2 == 0:
            self.running = False
            self.master.after(3600000, self.update_clock)
        else:
            self.running = True
            self.master.after(int(1000*(0.8**self.tetris.level)), self.update_clock)

    def update(self): # 更新方格色彩
        for i, _id in enumerate(self.rectangles):
            color_num = self.tetris.get_color(i//self.tetris.FIELD_WIDTH, i % self.tetris.FIELD_WIDTH) # 每个方格的编号整除宽度，得到行数，余数为列，通过get_color，给行和列的参数，得到色彩
            self.canvas.itemconfig(_id, fill=COLORS[color_num]) # 画出色彩
            self.canvas.itemconfig('bd', bd='gray')
        for i, _id in enumerate(self.rectangles2):
            self.canvas2.itemconfig(_id, fill='black')
        for i, _id in enumerate(self.rectangles2):
            for r,c in self.tetris.TETROMINOS[self.tetris.choice_next]:
                if i == (r if self.tetris.tetris_type=='I' else r+1)*4 + (c+1 if self.tetris.tetris_type!='I' else c) :
                    self.canvas2.itemconfig(_id, fill=COLORS[self.tetris.choice_next+1])
        self.status_msg['text'] = "\n\n\n分数：{}\n\n级别：{}\n\n已消：{}".format(self.tetris.score, self.tetris.level, self.tetris.total_lines_eliminated)
        if self.tetris.game_start_again and self.tetris.game_over==False:
            self.T3 += self.T2 - self.T1
            self.T1 = time.time()
        struct_time = time.gmtime(self.T2 - self.T1)
        if struct_time.tm_min >= 59:            
            timer = '\n\n00分钟00秒\n'.format(struct_time.tm_min, struct_time.tm_sec)
        else:
            timer = '\n\n{0}分钟{1}秒\n'.format(struct_time.tm_min, struct_time.tm_sec)
        self.timer_msg['text'] =  timer
        self.game_over_msg['text'] = "\n游戏结束\n按UP键\n重新开始\n\n\n" if self.tetris.game_over else ""
        struct_time_accumulation = time.gmtime(self.T3)
        self.biggest_score = max(self.tetris.score, self.biggest_score)
        # try:
        if self.biggest_score > HIGHEST_SCORE_OF_HISTORY and self.tetris.game_over:
            file = open(os.getcwd() + '/.score.txt', mode='w+', encoding='UTF-8')
            file.write(str(self.biggest_score))
            file.close()
        # except:
        #     pass                       
        if self.tetris.total > 1:
            timer_accumulation_msg = '\n\n第{0}局\n\n累计时间\n{1}分钟{2}秒\n平均每局\n{3}分钟{4}秒\n\n最高分\n{5}\n\n历史最高分{6}'.format(self.tetris.total, struct_time_accumulation.tm_min, struct_time_accumulation.tm_sec,struct_time_accumulation.tm_min//(self.tetris.total-1),struct_time_accumulation.tm_sec//(self.tetris.total-1), self.biggest_score, HIGHEST_SCORE_OF_HISTORY if HIGHEST_SCORE_OF_HISTORY > self.biggest_score else self.biggest_score)
            self.timer_accumulation_msg['text'] = timer_accumulation_msg
        elif self.tetris.total >= 1 and self.tetris.score >= 100:
            timer_accumulation_msg = '\n\n第{0}局\n\n累计时间\n{1}分钟{2}秒\n\n最高分\n{3}\n\n历史最高分{4}'.format(self.tetris.total, struct_time_accumulation.tm_min, struct_time_accumulation.tm_sec, self.biggest_score, HIGHEST_SCORE_OF_HISTORY if HIGHEST_SCORE_OF_HISTORY > self.biggest_score else self.biggest_score)
            self.timer_accumulation_msg['text'] = timer_accumulation_msg
        else:
            timer_accumulation_msg = '规则说明\n\n一次行\n消1行得100分\n消2行得200分\n消3行得400分\n消4行得800分\n\n每级需要10行乘级别\n每升一级得分翻倍\n时间也将快20%'
            self.timer_accumulation_msg['text'] = timer_accumulation_msg
        if self.tetris.total == 1 and self.tetris.score < 100:
            self.instruction_msg['text'] = "操作说明：\n\n按左右下键移动\n按上键变形\n按空格键暂停或继续\n\n\n\n"
        else:
            self.instruction_msg['text'] = '\n\n\n\n\n'
root = tk.Tk() # 根窗口
root.title("俄罗斯方块")
root.geometry('500x700+400-5')
root['bg'] = 'black'
root.resizable(False,False)
app = Application(master=root) # 根窗口放进应用
app.mainloop() # 进入主循环，显示主窗口
